package ru.job4j.io;

import java.util.*;

public class ArgZip {

    private final String[] args;
    private Map<String, String> result = new LinkedHashMap<>();

    public ArgZip(String[] args) {
        this.args = args;
//        result = readArgs();
    }

    public boolean valid() {
        return true;
    }

    public String directory() {
//        return result.get("-d");
          return args[1];
    }


    public String exclude() {
//        return result.get("-e").substring(2);
        return args[3].substring(2);
    }

    public String output() {
//        return result.get("-o");
        return args[5];
    }

    private Map<String, String> readArgs() {
        Map<String, String> temp = new LinkedHashMap<>();
        if (valid()) {
            temp.put(args[0], args[1]);
            temp.put(args[2], args[3]);
            temp.put(args[4], args[5]);
        }
        return temp;
    }
}