[![Build Status](https://travis-ci.org/npabllla/job4j_design.svg?branch=master)](https://travis-ci.org/npabllla/job4j_design)
[![codecov](https://codecov.io/gh/npabllla/job4j_design/branch/master/graph/badge.svg?token=Y8X1T2U8LX)](https://codecov.io/gh/npabllla/job4j_design)
# job4j_design
